#include "start.h"
#define uchar unsigned char
sbit bai = P3 ^ 4;
sbit left = P3 ^ 0;
sbit right = P3 ^ 1;
sbit down = P3 ^ 2;
sbit up = P3 ^ 3;
char love[8][8] = {    {0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 1, 1, 0, 0, 0},
    {0, 0, 1, 1, 1, 1, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 0},
    {0, 1, 1, 1, 1, 1, 1, 0},
    {1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1},
    {0, 1, 1, 0, 0, 1, 1, 0},
};
uchar code xiaobai[] = {
    0xfe, 0xfd, 0xfb, 0xf7, 0xef, 0xdf, 0xbf, 0x7f, //�����������
    0xfe, 0xfc, 0xf8, 0xf0, 0xe0, 0xc0, 0x80, 0x00, //�����������
    0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe, 0xff, //��������ݼ�
    0x7e, 0xbd, 0xdb, 0xe7, 0xe7, 0xdb, 0xbd, 0x7e, //���߿�£��ֿ�
    0x7e, 0x3c, 0x18, 0x00, 0x00, 0x18, 0x3c, 0x7e, //���ߵ��Ӻ�ݼ�
    0x00
};//ȫ��
//�����ж�ѡ
uchar fen[10][8] = {
    {0xFF, 0xFF, 0xC3, 0xDB, 0xDB, 0xDB, 0xC3, 0xFF}	,
    {0xFF, 0xEF, 0xEF, 0xEF, 0xEF, 0xEF, 0xEF, 0xEF },
    {0xFF, 0xC1, 0xCF, 0xEF, 0xB7, 0xD7, 0xEF, 0xFF },
    {0xFF, 0xC7, 0xF7, 0xF7, 0xC7, 0xF7, 0xC7, 0xFF },
    {0xFF, 0xF7, 0xF7, 0xC3, 0xD7, 0xD7, 0xFF, 0xFF },
    {0xFF, 0xFF, 0xC3, 0xFB, 0xC3, 0xDF, 0xC7, 0xFF },
    {0xFF, 0xC3, 0xDB, 0xC3, 0xDF, 0xDF, 0xC7, 0xFF },
    {0xFF, 0xFB, 0xFB, 0xFB, 0xFB, 0xFB, 0xC3, 0xFF },
    {0xFF, 0xC3, 0xDB, 0xC3, 0xDB, 0xDB, 0xC3, 0xFF},
    {0xFF, 0xC3, 0xFB, 0xFB, 0xC3, 0xDB, 0xC3, 0xFF},
};
void delay(long int MS)
{
    char us, usn;
    while(MS != 0)
    {
        usn = 0;
        while(usn != 0)
        {
            us = 0xff;
            while (us != 0) {
                us--;
            };
            usn--;
        }
        MS--;
    }
}
void delayms(unsigned int xms)   //��ʱ���� ����ʱxms
{
    unsigned int i, j;
    for(i = 0; i < xms; i++)
        for(j = 0; j < 110; j++);
}
void show(void)
{
    int i, j;
    for(i = 0; i < 8; i++)
    {
        for(j = 0; j < 8; j++)
        {
            if(love[i][j] == 1)
            {
                P1 = 0xff;
                P0 = 0X00;
                P1 = P1 & (~(1 << j));
                P0 = 1 << (i);
            }
        }
    }
}
void delaypus(long int i)
{
    while(i--);
}
void showfen(int k)
{
    int i, n = 100;
    while(n--)
    {
        for(i = 0; i < 8; i++)
        {
            P0 = 1 << i;
            P1 = fen[k][i];
            delaypus(10);
            P1 = 0xff;
            P0 = 0x00;
        }
    }
}
void bee()
{
    int n = 200;
    while(n--)
    {   bai = 0;
        delayms(1);
        bai = 1;
        delayms(1);
    }

}
void bengan()
{

    int i, n = 100;
    P0 = 0xff;
    P1 = 0x00;
    delayms(1000);
    for(i = 0; i < 10; i++)
        showfen(i);
    bee ();//��������
    while(n--)show();
    n = 1000;
    for(i = 0; i < 33; i++)
    {
        P1 = xiaobai[i];
        P0 = 0xff;
        delaypus(10000 - i * 240);
    }
    for(i = 0; i < 7; i++)	 //������ʾ6��״̬
    {
        smgDisplay(i, 1); //��һλ��ʾ0
        memset(love, 0, sizeof(char) * 64); //����
        n = 500;
        switch(i)
        {
        case 0:
            love[7][2] = love[7][3] = love[7][4] = love[7][5] = 1  ;
            while(n--)show();
            break;
        case 2:
            love[7][2] = 1 ;
            love[6][2] = love[6][3] = love[6][4] = 1;
            while(n--)show();
            break;
        case 1:
            love[6][2] = love[6][3] = love[6][4] = 1 ;
            love[7][4] = 1 ;
            while(n--)show();
            break;
        case 3:
            love[7][3] = love[7][4] = 1;
            love[6][3] = love[6][4] = 1  ;
            while(n--)show();
            break;
        case 6:
            love[7][3] = love[7][4] = 1;
            love[6][2] = love[6][3] = 1;
            while(n--)show();
            break;
        case 5:
            love[7][3] = 1;
            love[6][4] = love[6][2] = love[6][3] = 1 ;
            while(n--)show();
            break;
        case 4:
            love[7][2] = love[7][3] = 1;
            love[6][3] = love[6][4] = 1;
            while(n--)show();
            break;
        default:
            break;
        }
    }
}
int  coll(void)
{
    bit k = 0;
    int i;
    for(i = 0; i < 4; i++)
    {
        if(y[i] == 7) //����
            k = 1;
        if(m[x[i]][y[i] + 1] == 1)
            k = 1;
    }
    return k;
}
void fix(void)
{
    int i;
    for(i = 0; i < 4; i++)
    {
        if(y[i] >= 0)m[x[i]][y[i]] = 1;
    }
    for(i = 0; i < 8; i++)
    {
        if(m[i][7] == 0)
            flag = 0;
    }
}

void disp(void)
{
    int i, j, k;
    for(i = 0; i < 8; i++)
    {   p[i] = ~(m[0][i] + 2 * m[1][i] + 4 * m[2][i] + 8 * m[3][i] + 16 * m[4][i] + 32 * m[5][i] + 64 * m[6][i] + 128 * m[7][i]); //x���ѡ��   ȡ���͵�ƽ��Ч
    }
    for(i = 7; i > 1; i--)
    {
        while(p[i] == 0) //x���ѡ��
        {
            for(j = i; j > 1; j--)
            {   for(k = 0; k < 8; k++)
                    m[k][j] = m[k][j - 1]; //����
                p[j] = p[j - 1];
            }
            for(k = 0; k < 8; k++)
                m[k][0] = 0; //��һ��Ϩ��
            p[0] = 0xff;
        }

    }
    for(i = 0; i < 4; i++)
    {   if(y[i] >= 0)
            p[y[i]] = p[y[i]] & (~table[N + x[i]]);
    }
}

void movx(int a)
{
    int i, k = 0;
    if(a < 0)
    {
        for(i = 0; i < 4; i++)
        {   if(x[i] == 0)
                k = 1;
            if(m[x[i] - 1][y[i]] == 1)
                k = 1;
        }
        if(!k)
        {
            for(i = 0; i < 4; i++)
                x[i] = x[i] + a;
        }
    }
    if(a > 0)
    {
        for(i = 0; i < 4; i++)
        {   if(x[i] == 7)
                k = 1;
            if(m[x[i] + 1][y[i]] == 1)
                k = 1;
        }
        if(!k)
        {
            for(i = 0; i < 4; i++)
                x[i] = x[i] + a;
        }
    }

}

void dwon(void)
{
    int i;
    if(coll() == 0)
        for(i = 0; i < 4; i++)
            y[i] = y[i] + 1;
}
void fastdwon(void)
{

    int i, j, max = 8, temp;
    if(coll() == 0)
    {
        for(i = 0; i < 4; i++)
        {
            for(j = 0; j < 8; j++)
            {
                if(m[x[i]][y[i]] == 1)
                {
                    temp = j;
                    if(temp < max)
                        max = temp;
                }
            }
            y[i] = y[i] + max + 1;
        }
        //	y[i]=y[i]+max+1;
    }
}
void key()
{

    if(left == 0)
    {   delay(5);
        if(left == 0) {
            movx(1);
            while(!left);
        }
    }
    if(down == 0)
    {   delay(5);
        if(down == 0) {
            fastdwon()/*dwon()*/;
            while(!down);
        }
    }
    if(right == 0)
    {   delay(5);
        if(right == 0) {
            movx(-1);
            while(!right);
        }
    }
    if(up == 0) //��ת
    {   delay(5);
        if(up == 0) {
            cir( );
            while(!up);
        }
    }
}

void set(void)
{
    uchar a;
    a = rand();
    switch(a % 7)
    {
    case 0:
        x[0] = 2;
        x[1] = 3;
        x[2] = 4;
        x[3] = 5;
        y[0] = -1;
        y[1] = -1;
        y[2] = -1;
        y[3] = -1;
        break;
    case 1:
        x[0] = 2;
        x[1] = 2;
        x[2] = 3;
        x[3] = 4;
        y[0] = -2;
        y[1] = -1;
        y[2] = -1;
        y[3] = -1;
        break;
    case 2:
        x[0] = 2;
        x[1] = 3;
        x[2] = 4;
        x[3] = 4;
        y[0] = -1;
        y[1] = -1;
        y[2] = -1;
        y[3] = -2;
        break;
    case 3:
        x[0] = 3;
        x[1] = 3;
        x[2] = 4;
        x[3] = 4;
        y[0] = -2;
        y[1] = -1;
        y[2] = -1;
        y[3] = -2;
        break;
    case 4:
        x[0] = 2;
        x[1] = 3;
        x[2] = 3;
        x[3] = 4;
        y[0] = -1;
        y[1] = -1;
        y[2] = -2;
        y[3] = -2;
        break;
    case 5:
        x[0] = 3;
        x[1] = 3;
        x[2] = 2;
        x[3] = 4;
        y[0] = -2;
        y[1] = -1;
        y[2] = -1;
        y[3] = -1;
        break;
    case 6:
        x[0] = 2;
        x[1] = 3;
        x[2] = 3;
        x[3] = 4;
        y[0] = -2;
        y[1] = -2;
        y[2] = -1;
        y[3] = -2;
        break;
    default:
        break;
    }
}

void over(void)
{
    bit k = 0;
    int i;
    for(i = 0; i < 8; i++)
        if(m[i][0] == 1) //����ȫΪһ��Ϸ����
            k = 1;
    if(k)
    {
        memset(m, 0, sizeof(char) * 64); //����
        TR0 = 0;
        showfen(score);    //��ʾ����
        TR0 = 1;
    }
}
void cir(void)   //˳��ת90��
{
    int i;
    bit k = 0;
    char tempx[4];
    char tempy[4];
    for(i = 0; i < 4; i++)
    {
        tempx[i] = x[1] - y[i] + y[1];
        tempy[i] = y[1] + x[i] - x[1];
        if(m[tempx[i]][tempy[i]] == 1)
            k = 1;
    }
    if(k != 1)
    {
        for(i = 0; i < 4; i++)
        {
            x[i] = tempx[i];
            y[i] = tempy[i];
        }
    }
}


